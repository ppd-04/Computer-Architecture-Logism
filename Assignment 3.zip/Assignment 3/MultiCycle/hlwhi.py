import sys
import re

class CustomMIPSAssembler:
    def __init__(self):
        # Opcode mappings based on Group 1 A2: BDNKMFJALIPHGOEC
        self.OPCODES = {
            'addi': 0x0, 'subi': 0x1, 'beq': 0x2, 'nor': 0x3,
            'sw': 0x4,   'andi': 0x5, 'srl': 0x6, 'add': 0x7,
            'lw': 0x8,   'sll': 0x9,  'j': 0xA,   'ori': 0xB,
            'or': 0xC,   'bne': 0xD,  'and': 0xE, 'sub': 0xF
        }
        
        # Register to 4-bit binary mappings
        self.REGISTERS = {
            '$zero': 0x0, '$t0': 0x1, '$t1': 0x2, '$t2': 0x3,
            '$t3': 0x4,   '$t4': 0x5, '$sp': 0xF
        }

    def parse_line(self, line):
        line = line.split('#')[0].strip()
        if not line:
            return []
        line = re.sub(r'[,\(\)]', ' ', line)
        return line.split()

    def assemble(self, source_code):
        hex_output = ["v2.0 raw"]
        
        for line in source_code.strip().split('\n'):
            tokens = self.parse_line(line)
            if not tokens:
                continue
                
            inst = tokens[0]
            opcode = self.OPCODES[inst]
            machine_code = 0
            
            if inst in ['add', 'sub', 'and', 'or', 'nor']:
                rd = self.REGISTERS[tokens[1]]
                rs = self.REGISTERS[tokens[2]]
                rt = self.REGISTERS[tokens[3]]
                machine_code = (opcode << 12) | (rs << 8) | (rt << 4) | rd

            elif inst in ['addi', 'subi', 'andi', 'ori']:
                rt = self.REGISTERS[tokens[1]]
                rs = self.REGISTERS[tokens[2]]
                imm = int(tokens[3]) & 0xF 
                machine_code = (opcode << 12) | (rs << 8) | (rt << 4) | imm

            elif inst in ['beq', 'bne']:
                rs = self.REGISTERS[tokens[1]]
                rt = self.REGISTERS[tokens[2]]
                imm = int(tokens[3]) & 0xF
                machine_code = (opcode << 12) | (rs << 8) | (rt << 4) | imm

            elif inst in ['lw', 'sw']:
                rt = self.REGISTERS[tokens[1]]
                offset = int(tokens[2]) & 0xF
                rs = self.REGISTERS[tokens[3]]
                machine_code = (opcode << 12) | (rs << 8) | (rt << 4) | offset

            elif inst in ['sll', 'srl']:
                rd = self.REGISTERS[tokens[1]]
                rs = self.REGISTERS[tokens[2]]
                shamt = int(tokens[3]) & 0xF
                machine_code = (opcode << 12) | (rs << 8) | (rd << 4) | shamt

            elif inst == 'j':
                target = int(tokens[1]) & 0xFF 
                machine_code = (opcode << 12) | (target << 4) | 0x0
            
            else:
                raise ValueError(f"Unknown instruction: {inst}")
                
            hex_output.append(f"{machine_code:04X}")
            
        return " ".join(hex_output)

if __name__ == "__main__":
    assembler = CustomMIPSAssembler()

    # Check if a file was provided as a command-line argument
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        try:
            with open(file_path, 'r') as file:
                asm_code = file.read()
        except FileNotFoundError:
            print(f"Error: The file '{file_path}' was not found.")
            sys.exit(1)
    else:
        # Fallback to multi-line console input
        print("Paste your MIPS assembly code below.")
        print("Press Ctrl+D (Linux/Mac) or Ctrl+Z followed by Enter (Windows) when finished:")
        try:
            asm_code = sys.stdin.read()
        except KeyboardInterrupt:
            print("\nAssembly aborted.")
            sys.exit(0)

    if asm_code.strip():
        try:
            logisim_hex = assembler.assemble(asm_code)
            print("\n--- Logisim ROM Hex Output ---")
            print(logisim_hex)
        except Exception as e:
            print(f"\nAssembly Error: {e}")
    else:
        print("\nNo assembly code provided.")


# addi $t0, $zero, 3
# addi $t1, $zero, 5
# subi $sp, $sp, 1
# sw $t0, 0($sp)
# subi $sp, $sp, 1
# sw $t1, 0($sp)
# lw $t2, 0($sp)
# addi $sp, $sp, 1
# lw $t3, 0($sp)
# addi $sp, $sp, 1
# addi $t0, $zero, 5
# addi $t1, $zero, 2
# add $t2, $t0, $t1
# sw $t2, 0($zero)
# lw $t3, 0($zero)
# sll $t4, $t1, 1
# and $t2, $t3, $t4
# subi $t4, $t4, 4
# beq $t4, $zero, 1
# ori $t4, $zero, 15
# j 0